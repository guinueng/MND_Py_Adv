from django.shortcuts import render
from django.urls import reverse
from django.views.generic import CreateView
from commentapp.models import Comment
from commentapp.forms import Comment_Creation_Form
# Create your views here.


class Comment_Create_View(CreateView):
    model = Comment
    form_class = Comment_Creation_Form
    template_name = 'commentapp/create.html'

    def get_success_url(self):
        return reverse('articleapp:detail', kwargs={'pk': self.object.article.pk})
