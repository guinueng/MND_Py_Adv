from django.apps import AppConfig


class ComentappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'comentapp'
